package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class AddModifyStoreView extends JDialog {
	private JTextField storeNameTextField;
	private JTextField locationTextField;
	private JTextField openHourTextField;
	private JTextField closeHourTextField;
	private JButton okButton;

	public AddModifyStoreView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Add Store");
		this.setBounds(200, 200, 368, 260);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Store Name:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(1, 24, 108, 15);
		getContentPane().add(lblNewLabel);

		storeNameTextField = new JTextField();
		storeNameTextField.setBounds(119, 24, 156, 21);
		getContentPane().add(storeNameTextField);
		storeNameTextField.setColumns(10);

		JLabel lblPrice = new JLabel("Location:");
		lblPrice.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPrice.setBounds(1, 57, 108, 15);
		getContentPane().add(lblPrice);

		locationTextField = new JTextField();
		locationTextField.setColumns(10);
		locationTextField.setBounds(119, 57, 156, 21);
		getContentPane().add(locationTextField);

		JLabel lblNewLabel_1_1_1 = new JLabel("Open Hour:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setBounds(1, 88, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1);

		openHourTextField = new JTextField();
		openHourTextField.setColumns(10);
		openHourTextField.setBounds(119, 88, 156, 21);
		getContentPane().add(openHourTextField);

		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Close Hour:");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1.setBounds(1, 119, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1_1_1);

		closeHourTextField = new JTextField();
		closeHourTextField.setColumns(10);
		closeHourTextField.setBounds(119, 119, 156, 21);
		getContentPane().add(closeHourTextField);

		okButton = new JButton("OK");
		okButton.setBounds(44, 172, 95, 25);
		getContentPane().add(okButton);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeDialog();
			}
		});
		btnCancel.setBounds(202, 172, 95, 25);
		getContentPane().add(btnCancel);
	}

	private void closeDialog() {
		this.setVisible(false);
	}
	
	// clear user input data
	public void clear() {
		this.storeNameTextField.setText("");
		this.locationTextField.setText("");
		this.openHourTextField.setText("");
		this.closeHourTextField.setText("");
	}

	public JTextField getStoreNameTextField() {
		return storeNameTextField;
	}

	public JTextField getLocationTextField() {
		return locationTextField;
	}

	public JTextField getOpenHourTextField() {
		return openHourTextField;
	}

	public JTextField getCloseHourTextField() {
		return closeHourTextField;
	}

	public JButton getOkButton() {
		return okButton;
	}
}

