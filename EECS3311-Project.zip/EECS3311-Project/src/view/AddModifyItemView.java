package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import model.Category;
import model.Store;

public class AddModifyItemView extends JDialog {
	private JTextField itemNameTextField;
	private JTextField priceTextField;
	private JTextField aisleTextField;
	private JTextField stockTextField;
	private JComboBox storeComboBox;
	private JComboBox onSaleComboBox;
	private JComboBox categoryComboBox;
	private JButton addItemButton;

	public AddModifyItemView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Add Item");
		this.setBounds(200, 200, 400, 356);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Item Name:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(1, 24, 108, 15);
		getContentPane().add(lblNewLabel);

		itemNameTextField = new JTextField();
		itemNameTextField.setBounds(119, 24, 156, 21);
		getContentPane().add(itemNameTextField);
		itemNameTextField.setColumns(10);

		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPrice.setBounds(1, 57, 108, 15);
		getContentPane().add(lblPrice);

		priceTextField = new JTextField();
		priceTextField.setColumns(10);
		priceTextField.setBounds(119, 57, 156, 21);
		getContentPane().add(priceTextField);

		JLabel lblNewLabel_1_1 = new JLabel("Store:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setBounds(1, 92, 108, 15);
		getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("Aisle:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1.setBounds(1, 123, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1);

		aisleTextField = new JTextField();
		aisleTextField.setColumns(10);
		aisleTextField.setBounds(119, 123, 156, 21);
		getContentPane().add(aisleTextField);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("On Sale:");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1.setBounds(1, 162, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1_1);

		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Stock:");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1.setBounds(1, 194, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1_1_1);

		stockTextField = new JTextField();
		stockTextField.setColumns(10);
		stockTextField.setBounds(119, 194, 156, 21);
		getContentPane().add(stockTextField);

		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Category:");
		lblNewLabel_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1_1_1_1_1.setBounds(1, 225, 108, 15);
		getContentPane().add(lblNewLabel_1_1_1_1_1_1);

		categoryComboBox = new JComboBox();
		categoryComboBox.setBounds(119, 225, 156, 23);
		getContentPane().add(categoryComboBox);

		storeComboBox = new JComboBox();
		storeComboBox.setBounds(119, 91, 156, 23);
		getContentPane().add(storeComboBox);

		onSaleComboBox = new JComboBox();
		onSaleComboBox.setModel(new DefaultComboBoxModel(new String[] {"false", "true"}));
		onSaleComboBox.setBounds(119, 161, 156, 23);
		getContentPane().add(onSaleComboBox);

		addItemButton = new JButton("OK");
		addItemButton.setBounds(45, 274, 95, 25);
		getContentPane().add(addItemButton);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeDialog();
			}
		});
		btnCancel.setBounds(229, 274, 95, 25);
		getContentPane().add(btnCancel);
	}

	private void closeDialog() {
		this.setVisible(false);
	}

	// display category list in the ComboBox
	public void setCategoryList(List<Category> categoryList) {
		categoryComboBox.removeAllItems();
		for (Category c : categoryList) {
			categoryComboBox.addItem(c);
		}
	}

	// display store list in the ComboBox
	public void setStoreList(List<Store> storeList) {
		storeComboBox.removeAllItems();
		for (Store c : storeList) {
			storeComboBox.addItem(c);
		}
	}

	public JTextField getItemNameTextField() {
		return itemNameTextField;
	}

	public JTextField getPriceTextField() {
		return priceTextField;
	}

	public JTextField getAisleTextField() {
		return aisleTextField;
	}

	public JTextField getStockTextField() {
		return stockTextField;
	}

	public JComboBox getStoreComboBox() {
		return storeComboBox;
	}

	public JComboBox getOnSaleComboBox() {
		return onSaleComboBox;
	}

	public JComboBox getCategoryComboBox() {
		return categoryComboBox;
	}

	public JButton getAddItemButton() {
		return addItemButton;
	}
	
	// clear user input data
	public void clear() {
		this.itemNameTextField.setText("");
		this.priceTextField.setText("");
		this.aisleTextField.setText("");
		this.stockTextField.setText("");
	}
}
