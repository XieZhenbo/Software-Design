package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class RecommandView extends JDialog {
	private JTable itemListTable;
	private Vector<String> title;
	private JFrame parent;
	
	public RecommandView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Recommand list");
		String[] titles = { "StoreName", "Aisle", "ProductName", "Price", "Category", "OnSale" };
		title = new Vector<String>();
		for (String t : titles) {
			title.add(t);
		}
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		JButton btnNewButton = new JButton("Close");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});
		panel.add(btnNewButton);

		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);

		Vector<Vector<Object>> data = new Vector<Vector<Object>>();
		itemListTable = new JTable();
		scrollPane.setViewportView(itemListTable);
		itemListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		this.setBounds(100, 100, 600, 400);
	}

	public void setItemsData(Vector<Vector<Object>> data) {
		TableModel tableModel = new DefaultTableModel(data, title) {
			public Class getColumnClass(int column) {
				if(column == 0 || column == 3 || column == 4) {
					return Integer.class;
				} else {
					return Object.class;
				}
			}
		};
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
		itemListTable.setRowSorter(sorter);
		itemListTable.setModel(tableModel);
	}

	public JTable getItemListTable() {
		return itemListTable;
	}

	public Vector<String> getProductTableTitle() {
		return title;
	}

	private void cancelActionPerformed(){
		this.setVisible(false);
	}
}
