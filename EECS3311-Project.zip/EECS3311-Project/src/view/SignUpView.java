package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import model.Store;

public class SignUpView extends JDialog {
	private JTextField fullNameTextField;
	private JTextField accountNameTextField;
	private JTextField passwordTextField;
	private JButton signUpButton;
	private JComboBox roleComboBox;
	private JComboBox storeComboBox;

	public SignUpView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Sign up");
		this.setBounds(200, 200, 456, 364);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Role:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(59, 44, 99, 15);
		getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Full Name:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(59, 83, 99, 15);
		getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Account Name:");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(59, 118, 99, 15);
		getContentPane().add(lblNewLabel_2);

		fullNameTextField = new JTextField();
		fullNameTextField.setBounds(168, 80, 182, 21);
		getContentPane().add(fullNameTextField);
		fullNameTextField.setColumns(10);

		accountNameTextField = new JTextField();
		accountNameTextField.setBounds(168, 115, 182, 21);
		getContentPane().add(accountNameTextField);
		accountNameTextField.setColumns(10);

		roleComboBox = new JComboBox();
		roleComboBox.setModel(new DefaultComboBoxModel(new String[] { "customer", "manager", "admin" }));
		roleComboBox.setBounds(168, 40, 114, 23);
		getContentPane().add(roleComboBox);

		JLabel lblNewLabel_3 = new JLabel("Store: ");
		lblNewLabel_3.setBounds(104, 196, 54, 15);
		getContentPane().add(lblNewLabel_3);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);

		storeComboBox = new JComboBox();
		storeComboBox.setBounds(168, 188, 114, 23);
		getContentPane().add(storeComboBox);

		JLabel lblNewLabel_2_1 = new JLabel("Account Password:");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2_1.setBounds(10, 156, 148, 15);
		getContentPane().add(lblNewLabel_2_1);

		passwordTextField = new JTextField();
		passwordTextField.setColumns(10);
		passwordTextField.setBounds(168, 153, 182, 21);
		getContentPane().add(passwordTextField);

		signUpButton = new JButton("OK");
		signUpButton.setBounds(74, 261, 95, 25);
		getContentPane().add(signUpButton);

		JButton cancelButton = new JButton("Close");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelAction();
			}
		});
		cancelButton.setBounds(255, 261, 95, 25);
		getContentPane().add(cancelButton);
	}

	private void cancelAction() {
		this.setVisible(false);
	}

	public JTextField getFullNameTextField() {
		return fullNameTextField;
	}

	public JTextField getAccountNameTextField() {
		return accountNameTextField;
	}

	public JTextField getPasswordTextField() {
		return passwordTextField;
	}

	public JButton getSignUpButton() {
		return signUpButton;
	}

	public JComboBox getRoleComboBox() {
		return roleComboBox;
	}

	public JComboBox getStoreComboBox() {
		return storeComboBox;
	}

	// display store list in the ComboBox
	public void setStoreList(List<Store> storeList) {
		storeComboBox.removeAllItems();
		for (Store c : storeList) {
			storeComboBox.addItem(c);
		}
	}

}
