package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class PurchaseListView extends JDialog {
	private JTable itemListTable;
	private Vector<String> title;
	private JButton modifyButton;
	private JLabel roleLabel;
	private JLabel usernameLabel;
	private JButton addItemButton;
	private JButton deleteItemButton;
	private JFrame parent;
	
	public PurchaseListView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Purchase list");
		String[] titles = { "PurchaseID", "ProductName", "Price", "Quantity", "StoreName", "Aisle"};
		title = new Vector<String>();
		for (String t : titles) {
			title.add(t);
		}
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);

		modifyButton = new JButton("Modify");
		panel.add(modifyButton);
		
		addItemButton = new JButton("Add");
		panel.add(addItemButton);
		
		deleteItemButton = new JButton("Delete");
		panel.add(deleteItemButton);
		
		JButton btnNewButton = new JButton("Close");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});
		panel.add(btnNewButton);

		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);

		Vector<Vector<Object>> data = new Vector<Vector<Object>>();
		itemListTable = new JTable();
		scrollPane.setViewportView(itemListTable);
		itemListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("  ");
		menuBar.add(mnNewMenu);

		Component horizontalStrut = Box.createHorizontalStrut(329);
		menuBar.add(horizontalStrut);

		JLabel lblNewLabel_2 = new JLabel("Login user: ");
		menuBar.add(lblNewLabel_2);

		usernameLabel = new JLabel("");
		usernameLabel.setForeground(Color.RED);
		menuBar.add(usernameLabel);

		Component horizontalStrut_1 = Box.createHorizontalStrut(98);
		menuBar.add(horizontalStrut_1);

		JLabel lblNewLabel_4 = new JLabel("Role: ");
		menuBar.add(lblNewLabel_4);

		roleLabel = new JLabel("");
		roleLabel.setForeground(Color.RED);
		menuBar.add(roleLabel);

		JLabel lblNewLabel_1 = new JLabel("");
		menuBar.add(lblNewLabel_1);
		this.setBounds(50, 50, 700, 500);
	}

	public void setItemsData(Vector<Vector<Object>> data) {
		TableModel tableModel = new DefaultTableModel(data, title) {
			public Class getColumnClass(int column) {
				if(column == 0 || column == 3 || column == 4) {
					return Integer.class;
				} else {
					return Object.class;
				}
			}
		};
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
		itemListTable.setRowSorter(sorter);
		itemListTable.setModel(tableModel);
	}

	public void addModifyLisener(ActionListener listener) {
		modifyButton.addActionListener(listener);
	}

	public JLabel getRoleLabel() {
		return roleLabel;
	}

	public JLabel getUsernameLabel() {
		return usernameLabel;
	}

	public JTable getItemListTable() {
		return itemListTable;
	}

	public Vector<String> getProductTableTitle() {
		return title;
	}

	public JButton getModifyButton() {
		return modifyButton;
	}

	public JButton getAddItemButton() {
		return addItemButton;
	}

	public JButton getDeleteItemButton() {
		return deleteItemButton;
	}
	private void cancelActionPerformed(){
		this.setVisible(false);
	}
}
