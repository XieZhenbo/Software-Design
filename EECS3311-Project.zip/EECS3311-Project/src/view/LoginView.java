package view;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class LoginView extends JDialog {
	private JTextField usernameTextField;
	private JTextField passwordTextField;
	private JButton logInButton;
	private JButton signUpButton;
	private JButton cancelButton;
	private boolean isLogined;

	public LoginView(JFrame parent) {
		super(parent);
		this.setModal(true);
		setTitle("Log In");
		this.setBounds(200, 200, 400, 283);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("username:");
		lblNewLabel.setBounds(74, 60, 77, 15);
		getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("password:");
		lblNewLabel_1.setBounds(74, 122, 64, 15);
		getContentPane().add(lblNewLabel_1);

		usernameTextField = new JTextField();
		usernameTextField.setBounds(148, 57, 159, 21);
		getContentPane().add(usernameTextField);
		usernameTextField.setColumns(10);

		passwordTextField = new JTextField();
		passwordTextField.setBounds(148, 119, 159, 21);
		getContentPane().add(passwordTextField);
		passwordTextField.setColumns(10);

		logInButton = new JButton("Log in");
		logInButton.setBounds(23, 177, 95, 25);
		getContentPane().add(logInButton);

		signUpButton = new JButton("Sign up");
		signUpButton.setBounds(148, 177, 95, 25);
		getContentPane().add(signUpButton);
		
		cancelButton = new JButton("Cancel");
		cancelButton.setBounds(269, 177, 95, 25);
		getContentPane().add(cancelButton);
	}

	public JTextField getUsernameTextField() {
		return usernameTextField;
	}

	public JTextField getPasswordTextField() {
		return passwordTextField;
	}

	public JButton getLogInButton() {
		return logInButton;
	}

	public JButton getSignUpButton() {
		return signUpButton;
	}

	public JButton getCancelButton() {
		return cancelButton;
	}

	public boolean isLogined() {
		return isLogined;
	}

	public void setLogined(boolean isLogined) {
		this.isLogined = isLogined;
	}
}
