package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import model.Category;
import model.Store;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class SmartShopperView extends JFrame {
	private JTable productListTable;
	private Vector<String> productTableTitle;
	private JComboBox categoryComboBox;
	private JComboBox storeComboBox;
	private JButton modifyButton;
	private JLabel roleLabel;
	private JLabel usernameLabel;
	private JButton addItemButton;
	private JButton deleteItemButton;
	private JButton storeListButton;
	private JButton peopleListButton;
	private JButton purchaseListButton;
	private JButton addPurchaseButton;
	private Component horizontalStrut_2;
	private Component horizontalStrut_3;
	private JLabel lblNewLabel_3;
	private JButton searchButton;
	private JTextField productNametextField;
	private Component horizontalStrut_4;
	private Component horizontalStrut_5;
	private Component horizontalStrut_6;
	private JButton recommandButton;

	public SmartShopperView() {
		setTitle("SmartShopper System");
		String[] titles = { "Prid", "Name", "Price", "Store", "Aisle", "OnSale", "Stock", "Category" };
		productTableTitle = new Vector<String>();
		for (String t : titles) {
			productTableTitle.add(t);
		}
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);

		JLabel lblStore = new JLabel("Store:");
		panel.add(lblStore);

		storeComboBox = new JComboBox();
		panel.add(storeComboBox);

		JLabel lblNewLabel = new JLabel("Category:");
		panel.add(lblNewLabel);

		categoryComboBox = new JComboBox();
		panel.add(categoryComboBox);

		modifyButton = new JButton("Modify");
		panel.add(modifyButton);
		
		addItemButton = new JButton("Add");
		panel.add(addItemButton);
		
		deleteItemButton = new JButton("Delete");
		panel.add(deleteItemButton);
		
		purchaseListButton = new JButton("Purchase List");
		panel.add(purchaseListButton);
		
		addPurchaseButton = new JButton("Add Purchase");
		panel.add(addPurchaseButton);
		
		recommandButton = new JButton("Recommand");
		panel.add(recommandButton);

		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);

		Vector<Vector<Object>> data = new Vector<Vector<Object>>();
		productListTable = new JTable();
		scrollPane.setViewportView(productListTable);
		productListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		menuBar.add(btnNewButton);

		Component horizontalStrut = Box.createHorizontalStrut(8);
		menuBar.add(horizontalStrut);

		JLabel lblNewLabel_2 = new JLabel("Login user: ");
		menuBar.add(lblNewLabel_2);

		usernameLabel = new JLabel("");
		usernameLabel.setForeground(Color.RED);
		menuBar.add(usernameLabel);

		Component horizontalStrut_1 = Box.createHorizontalStrut(98);
		menuBar.add(horizontalStrut_1);

		JLabel lblNewLabel_4 = new JLabel("Role: ");
		menuBar.add(lblNewLabel_4);
		
				roleLabel = new JLabel("                ");
				roleLabel.setForeground(Color.RED);
				menuBar.add(roleLabel);
		
		horizontalStrut_2 = Box.createHorizontalStrut(20);
		menuBar.add(horizontalStrut_2);
		
		storeListButton = new JButton("Store List");
		menuBar.add(storeListButton);
		
		horizontalStrut_3 = Box.createHorizontalStrut(20);
		menuBar.add(horizontalStrut_3);
		
		peopleListButton = new JButton("People List");
		menuBar.add(peopleListButton);
		
		horizontalStrut_4 = Box.createHorizontalStrut(20);
		menuBar.add(horizontalStrut_4);
		
		lblNewLabel_3 = new JLabel("ProductName:");
		menuBar.add(lblNewLabel_3);
		
		horizontalStrut_5 = Box.createHorizontalStrut(9);
		menuBar.add(horizontalStrut_5);
		
		productNametextField = new JTextField();
		menuBar.add(productNametextField);
		productNametextField.setColumns(10);
		
		horizontalStrut_6 = Box.createHorizontalStrut(8);
		menuBar.add(horizontalStrut_6);
		
		searchButton = new JButton("Search");
		menuBar.add(searchButton);

		JLabel lblNewLabel_1 = new JLabel("");
		menuBar.add(lblNewLabel_1);
		this.setBounds(50, 50, 950, 600);
	}

	public void setProductData(Vector<Vector<Object>> data) {
		TableModel tableModel = new DefaultTableModel(data, productTableTitle) {
			public Class getColumnClass(int column) {
				if(column == 0 || column == 2 || column == 6) {
					return Integer.class;
				} else {
					return Object.class;
				}
			}
		};
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
		productListTable.setRowSorter(sorter);
		productListTable.setModel(tableModel);
	}

	// display store list in the ComboBox
	public void setStoreList(List<Store> storeList) {
		storeComboBox.removeAllItems();
		storeComboBox.addItem("ALL");
		for (Store c : storeList) {
			storeComboBox.addItem(c);
		}
	}

	// display category list in the ComboBox
	public void setCategoryList(List<Category> categoryList) {
		categoryComboBox.removeAllItems();
		categoryComboBox.addItem("ALL");
		for (Category c : categoryList) {
			categoryComboBox.addItem(c);
		}
	}

	public void addCategoryComboBoxLisener(ActionListener listener) {
		categoryComboBox.addActionListener(listener);
	}

	public void addStoreComboBoxLisener(ActionListener listener) {
		storeComboBox.addActionListener(listener);
	}

	public void addModifyLisener(ActionListener listener) {
		modifyButton.addActionListener(listener);
	}

	public JLabel getRoleLabel() {
		return roleLabel;
	}

	public JLabel getUsernameLabel() {
		return usernameLabel;
	}

	public JTable getProductListTable() {
		return productListTable;
	}

	public Vector<String> getProductTableTitle() {
		return productTableTitle;
	}

	public JComboBox getCategoryComboBox() {
		return categoryComboBox;
	}

	public JComboBox getStoreComboBox() {
		return storeComboBox;
	}

	public JButton getModifyButton() {
		return modifyButton;
	}

	public JButton getAddItemButton() {
		return addItemButton;
	}

	public JButton getDeleteItemButton() {
		return deleteItemButton;
	}

	public JButton getStoreListButton() {
		return storeListButton;
	}

	public JButton getPeopleListButton() {
		return peopleListButton;
	}

	public JButton getPurchaseListButton() {
		return purchaseListButton;
	}

	public JButton getAddPurchaseButton() {
		return addPurchaseButton;
	}

	public Component getHorizontalStrut_2() {
		return horizontalStrut_2;
	}

	public Component getHorizontalStrut_3() {
		return horizontalStrut_3;
	}

	public JLabel getLblNewLabel_3() {
		return lblNewLabel_3;
	}

	public JButton getSearchButton() {
		return searchButton;
	}

	public JTextField getProductNametextField() {
		return productNametextField;
	}

	public Component getHorizontalStrut_4() {
		return horizontalStrut_4;
	}

	public Component getHorizontalStrut_5() {
		return horizontalStrut_5;
	}

	public Component getHorizontalStrut_6() {
		return horizontalStrut_6;
	}

	public JButton getRecommandButton() {
		return recommandButton;
	}
}
