package unit_test;

import org.junit.Assert;
import org.junit.Test;

import model.People;
import model.Product;
import model.SmartShopperModel;
import model.Store;

public class SmartShopperModelTest {
	@Test
	public void testIsCustomer() {
		SmartShopperModel model = new SmartShopperModel();
		model.setLoginUser(new People(1, "test", "test", "test", "customer"));
		Assert.assertTrue(model.isCustomer());
	}
	
	@Test
	public void testIsAdmin() {
		SmartShopperModel model = new SmartShopperModel();
		model.setLoginUser(new People(1, "test", "test", "test", "admin"));
		Assert.assertTrue(model.isAdministrator());
	}
	
	@Test
	public void testIsManager() {
		SmartShopperModel model = new SmartShopperModel();
		model.setLoginUser(new People(1, "test", "test", "test", "manager"));
		Assert.assertTrue(model.isManager());
	}
	
	@Test
	public void testCategory() {
		SmartShopperModel model = new SmartShopperModel();
		model.setCategoryID(3);
		Assert.assertEquals(3, model.getCategoryID());
	}
	
	@Test
	public void testGetStore() {
		SmartShopperModel model = new SmartShopperModel();
		model.setStoreID(5);
		Assert.assertEquals(5, model.getStoreID());
	}
	
	@Test
	public void testPeople() {
		People people = new People(1, "jack smith", "jack", "12345", "customer");
		Assert.assertEquals(people.getFullName(), "jack smith");
		Assert.assertEquals(people.getUsername(), "jack");
		Assert.assertEquals(people.getPassword(), "12345");
		Assert.assertEquals(people.getRole(), "customer");
	}
	
	@Test
	public void testStore() {
		Store store = new Store(1, "store1", "street1", 9, 18);
		Assert.assertEquals(store.getSid(), 1);
		Assert.assertEquals(store.getName(), "store1");
		Assert.assertEquals(store.getLocation(), "street1");
		Assert.assertEquals(store.getOpenHour(), 9);
		Assert.assertEquals(store.getCloseHour(), 18);
	}
	
	
	@Test
	public void testProduct() {
		Product product = new Product(1, "use mouse", 15.00, 2, "A001", true, 10, 5);
		Assert.assertEquals(product.getPrid(), 1);
		Assert.assertEquals(product.getName(), "use mouse");
		Assert.assertEquals(product.getAisle(), "A001");
		Assert.assertEquals(product.isOnSale(), true);
		Assert.assertEquals(product.getStock(), 10);
		Assert.assertEquals(product.getCategoryId(), 5);
	}
}
