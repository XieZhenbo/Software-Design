package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.Manager;
import model.ManagerMysql;
import model.People;
import model.PeopleMysql;
import model.SmartShopperModel;
import model.Store;
import view.LoginView;
import view.SignUpView;

// log in or sign up
public class LoginController {
	private SmartShopperModel smartShopperModel;
	private LoginView loginView;
	private SignUpView signUpView;
	private PeopleMysql peopleMysql;
	private ManagerMysql managerMysql;
	private JFrame parent;

	public LoginController(SmartShopperModel smartShopperModel, JFrame parent) {
		this.parent = parent;
		this.smartShopperModel = smartShopperModel;

		peopleMysql = new PeopleMysql();
		loginView = new LoginView(this.parent);
		signUpView = new SignUpView(this.parent);
		managerMysql = new ManagerMysql();
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initialize() throws Exception {
		initLoginView();
		initSignUpView();
	}

	// check if logined
	public boolean isLogined() {
		return this.smartShopperModel.getLoginUser() != null;
	}
	
	// user log in
	public boolean checkLogin() {
		if (!smartShopperModel.isLoginUser()) {
			loginView.setVisible(true);
		}
		if (this.smartShopperModel.getLoginUser() == null) {
			return false;
		} else {
			return true;
		}
	}

	// display log in window
	private void initLoginView() {
		// sign up's listener
		this.loginView.getSignUpButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				signUpView.setVisible(true);
			}
		});
		// add cancel button's action listener
		loginView.getCancelButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				loginView.setVisible(false);
			}
		});
		// add log in action listener
		loginView.getLogInButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = loginView.getUsernameTextField().getText();
				String password = loginView.getPasswordTextField().getText();
				if (username.isEmpty()) {
					JOptionPane.showMessageDialog(loginView, "Please enter username!");
				} else if (password.isEmpty()) {
					JOptionPane.showMessageDialog(loginView, "Please enter password!");
				} else {
					try {
						login(username, password);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});
	}

	public void login(String username, String password) throws Exception {
		People loginUser = peopleMysql.getPeople(username, password);
		// display error message if fail log in
		if (loginUser == null) {
			JOptionPane.showMessageDialog(loginView, "Invalid username or password!");
			loginView.setLogined(false);
		} else {
			// success log in
			loginView.setVisible(false);
			loginView.setLogined(true);
			smartShopperModel.setLoginUser(loginUser);
			// get manager and store data
			if (smartShopperModel.isManager()) {
				Manager manager = managerMysql.getManager(smartShopperModel.getLoginUser().getPid());
				smartShopperModel.setLoginManager(manager);
				Store store = smartShopperModel.getStoreById(manager.getSid());
				manager.setStore(store);
			}
		}
	}

	// set action listener in signUpView
	private void initSignUpView() {
		signUpView.setStoreList(smartShopperModel.getStoreList());
		signUpView.getSignUpButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String role = signUpView.getRoleComboBox().getSelectedItem().toString();
				String fullName = signUpView.getFullNameTextField().getText();
				String accountName = signUpView.getAccountNameTextField().getText();
				String password = signUpView.getPasswordTextField().getText();
				int storeID = ((Store) signUpView.getStoreComboBox().getSelectedItem()).getSid();
				if (fullName.isEmpty()) {
					JOptionPane.showMessageDialog(signUpView, "Please enter full name!");
				} else if (accountName.isEmpty()) {
					JOptionPane.showMessageDialog(signUpView, "Please enter account name!");
				} else if (password.isEmpty()) {
					JOptionPane.showMessageDialog(signUpView, "Please enter password!");
				} else {
					People people = new People(0, fullName, accountName, password, role);
					try {
						peopleMysql.insertPeople(people);
						if (people.getRole().equals("manager")) {
							Manager manager = new Manager(-1, people.getFullName(), people.getUsername(),
									people.getPassword(), people.getRole(), storeID);
							managerMysql.insertManager(manager);
						}
						JOptionPane.showMessageDialog(signUpView, "Success sign up!");
						signUpView.setVisible(false);
					} catch (Exception e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(signUpView, "Fail sign up!");
					}
				}
			}
		});
	}
}
