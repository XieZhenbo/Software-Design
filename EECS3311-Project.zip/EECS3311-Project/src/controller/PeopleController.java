package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.People;
import model.PeopleMysql;
import model.SmartShopperModel;
import view.AddModifyPeopleView;
import view.PeopleView;

// add, modify, delete People
public class PeopleController {
	private SmartShopperModel smartShopperModel;
	private PeopleView peopleView;
	private PeopleMysql peopleMysql;
	private AddModifyPeopleView addModifyPeopleView;
	private LoginController loginController;
	private JFrame parent;
	
	public PeopleController(SmartShopperModel smartShopperModel, JFrame parent) {
		this.smartShopperModel = smartShopperModel;
		this.peopleView = new PeopleView(parent);
		this.parent = parent;
		peopleMysql = new PeopleMysql();
		this.addModifyPeopleView = new AddModifyPeopleView(this.parent);
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		loginController = new LoginController(smartShopperModel, parent);
		this.addModifyPeopleView.setStoreList(this.smartShopperModel.getStoreList());
	}

	private void initialize() throws Exception {
		// add modify button's listener
		this.peopleView.addModifyLisener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					modifyButtonActionPerformed();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		// add item's listener
		this.peopleView.getAddItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// display log in window if not have log in
				try {
					if (checkLogin()) {
						displayAddOrModifyItemView(null);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		this.peopleView.getDeleteItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deletePeople();
			}
		});
		initAddItemView();
	}

	// modify item
	private void modifyButtonActionPerformed() throws Exception {
		// display log in window if not have log in
		if (!checkLogin()) {
			return;
		}
		int selectRow = this.peopleView.getItemListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(peopleView, "Please select one row!");
			return;
		}
		int id = (int) this.peopleView.getItemListTable().getValueAt(selectRow, 0);
		People people = peopleMysql.getPeople(id);
		this.smartShopperModel.setModifiedPeople(people);
		displayAddOrModifyItemView(people);
	}

	// user log in
	private boolean checkLogin() throws Exception {
		if (this.loginController.isLogined()) {
			return true;
		} else if (!loginController.checkLogin()) { // fail login
			return false;
		}
		// initialize data after first log in
		peopleView.getUsernameLabel().setText(smartShopperModel.getLoginUser().getFullName());
		peopleView.getRoleLabel().setText(smartShopperModel.getLoginUser().getRole());
		this.peopleView.getAddItemButton().setVisible(isCanModifyItem());
		this.peopleView.getModifyButton().setVisible(isCanModifyItem());
		this.peopleView.getDeleteItemButton().setVisible(isCanModifyItem());

		return true;
	}

	// delete item
	private void deletePeople() {
		try {
			if (!checkLogin()) {
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (!isCanModifyItem()) {
			JOptionPane.showMessageDialog(peopleView, "Only manager or administrator can delete!");
			return;
		}
		int selectRow = this.peopleView.getItemListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(peopleView, "Please select one row!");
			return;
		}
		// confirm with user to delete item
		if (JOptionPane.showConfirmDialog(peopleView, "Confirm to delete this row?") != JOptionPane.OK_OPTION) {
			return;
		}
		int id = (int) this.peopleView.getItemListTable().getValueAt(selectRow, 0);
		try {
			peopleMysql.deletePeople(id);
			JOptionPane.showMessageDialog(peopleView, "Success delete!");
			refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(peopleView, "Fail delete!");
		}
	}

	// only manager or administrator can add item
	private boolean isCanModifyItem() {
		return smartShopperModel.isAdministrator() || smartShopperModel.isManager();
	}

	// display add item's dialog
	private void displayAddOrModifyItemView(People people) {
		// add item
		if (people == null) {
			this.addModifyPeopleView.setTitle("Add People");
		} else {
			this.addModifyPeopleView.setTitle("Modify People");
		}
		this.addModifyPeopleView.clear();
		// modify item
		if (people != null) {
			this.addModifyPeopleView.getAccountNameTextField().setText(people.getFullName());
			this.addModifyPeopleView.getPasswordTextField().setText(people.getPassword());
		}
		// display window
		this.addModifyPeopleView.setVisible(true);
	}

	// set action listener in add item
	private void initAddItemView() {
		this.addModifyPeopleView.getOkButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addItemModifyItemActionPerformed();
			}
		});
	}

	private void addItemModifyItemActionPerformed() {
		if (this.addModifyPeopleView.getTitle().startsWith("Add")) {
			addPeople();
		} else {
			updatePeople();
		}
	}
	
	public void addPeople() {
		doAddOrModifyItem(null);
	}
	
	public void updatePeople() {
		doAddOrModifyItem(this.smartShopperModel.getModifiedPeople());
	}

	// add or modify people
	private void doAddOrModifyItem(People people) {
		String name = this.addModifyPeopleView.getFullNameTextField().getText();
		String username = this.addModifyPeopleView.getAccountNameTextField().getText();
		String password = this.addModifyPeopleView.getPasswordTextField().getText();
		String role = this.addModifyPeopleView.getRoleComboBox().getSelectedItem().toString();
		if (name.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyPeopleView, "Please enter full name!");
			return;
		} else if (password.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyPeopleView, "Please enter password!");
			return;
		}
		try {
			// insert
			if (people == null) {
				people = new People(-1, name, username, password, role);
				peopleMysql.insertPeople(people);
				JOptionPane.showMessageDialog(this.addModifyPeopleView, "Success add!");
			} else {
				// modify
				People newPeople = new People(-1, name, username, password, role);
				newPeople.setPid(people.getPid());
				peopleMysql.modify(newPeople);
				JOptionPane.showMessageDialog(this.addModifyPeopleView, "Success modify!");
			}
			this.addModifyPeopleView.setVisible(false);
			this.addModifyPeopleView.clear();
			this.refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// get item list
	private void refreshItemList() {
		try {
			peopleView.setItemsData(peopleMysql.getItemList());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// display the window
	public void displayWindow() {
		refreshItemList();
		peopleView.getAddItemButton().setVisible(this.smartShopperModel.isAdministrator());
		peopleView.getUsernameLabel().setText(this.smartShopperModel.getLoginUser().getFullName());
		peopleView.getRoleLabel().setText(this.smartShopperModel.getLoginUser().getRole());
		peopleView.setVisible(true);
	}
}

