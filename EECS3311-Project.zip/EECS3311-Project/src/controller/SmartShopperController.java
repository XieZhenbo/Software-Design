package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import model.Category;
import model.CategoryMysql;
import model.Product;
import model.ProductMysql;
import model.Purchase;
import model.PurchaseMysql;
import model.SmartShopperModel;
import model.Store;
import model.StoreMysql;
import view.AddModifyItemView;
import view.SmartShopperView;

// main controller
public class SmartShopperController {
	private SmartShopperModel smartShopperModel;
	private SmartShopperView smartShopperView;
	private ProductMysql productMysql;
	private CategoryMysql categoryMysql;
	private StoreMysql storeMysql;
	private PurchaseMysql purchaseMysql;
	private AddModifyItemView addModifyItemView;
	private LoginController loginController;
	private StoreController storeController;
	private PeopleController peopleController;
	private PurchaseListController purchaseListController;
	private RecommandController recommandController;
	
	public SmartShopperController(SmartShopperModel smartShopperModel, SmartShopperView smartShopperView) {
		this.smartShopperModel = smartShopperModel;
		this.smartShopperView = smartShopperView;
		productMysql = new ProductMysql();
		categoryMysql = new CategoryMysql();
		storeMysql = new StoreMysql();
		purchaseMysql = new PurchaseMysql();
		addModifyItemView = new AddModifyItemView(smartShopperView);
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		loginController = new LoginController(smartShopperModel, smartShopperView);
		storeController = new StoreController(smartShopperModel, smartShopperView);
		peopleController = new PeopleController(smartShopperModel, smartShopperView);
		purchaseListController = new PurchaseListController(smartShopperModel, smartShopperView);
		recommandController = new RecommandController(smartShopperModel, smartShopperView);
	}

	private void initialize() throws Exception {
		smartShopperModel.setStoreList(storeMysql.getAllStore());
		smartShopperModel.setCategoryList(categoryMysql.getAllCategory());
		// display product list
		this.smartShopperView.setProductData(productMysql.getItemList(-1, -1));
		// display category list
		this.smartShopperView.setCategoryList(smartShopperModel.getCategoryList());
		// display store list
		this.smartShopperView.setStoreList(smartShopperModel.getStoreList());
		this.smartShopperView.getPurchaseListButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				purchaseListButtonActionPerformed();
			}
		});
		this.smartShopperView.getStoreListButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				storeListButtonActionPerformed();
			}
		});
		this.smartShopperView.getPeopleListButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				peopleListButtonActionPerformed();				
			}
		});
		// display item list by category
		this.smartShopperView.addCategoryComboBoxLisener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (((JComboBox) arg0.getSource()).getSelectedItem().toString().equals("ALL")) {
					smartShopperModel.setCategoryID(-1);
				} else {
					Category category = (Category) ((JComboBox) arg0.getSource()).getSelectedItem();
					smartShopperModel.setCategoryID(category.getCid());
				}
				refreshItemList();
			}
		});
		// display item list by store
		this.smartShopperView.addStoreComboBoxLisener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (((JComboBox) arg0.getSource()).getSelectedItem().toString().equals("ALL")) {
					smartShopperModel.setStoreID(-1);
				} else {
					Store store = (Store) ((JComboBox) arg0.getSource()).getSelectedItem();
					smartShopperModel.setStoreID(store.getSid());
				}
				refreshItemList();
			}
		});
		// add modify button's listener
		this.smartShopperView.addModifyLisener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					modifyButtonActionPerformed();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		// add item's listener
		this.smartShopperView.getAddItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// display log in window if not have log in
				try {
					if (login()) {
						displayAddOrModifyItemView(null);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		// search product by product name
		this.smartShopperView.getSearchButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				search();
			}
		});
		this.smartShopperView.getDeleteItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteItem();
			}
		});
		this.smartShopperView.getAddPurchaseButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addPurchaseActionPerformed();
			}
		});
		this.smartShopperView.getRecommandButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				recommand();
			}
		});
		initAddItemView();
	}

	// recommand action
	public void recommand() {
		try {
			if(!login()) {
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.recommandController.displayWindow();
	}
	
	// customer add purchase list
	private void addPurchaseActionPerformed() {
		try {
			if(!login()) {
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		int selectRow = this.smartShopperView.getProductListTable().getSelectedRow();
		if(selectRow < 0) {
			JOptionPane.showMessageDialog(smartShopperView, "Please select one row!");
			return;
		}
		// ask user enter quantity
		int quantity = -1;
		String quantityString;
		quantityString = JOptionPane.showInputDialog("Please enter quantity: ");
		do {
			try {
				quantity = Integer.parseInt(quantityString);
			} catch (Exception e) {
				quantity = -1;
			}
			if(!(quantity >= 1 && quantity < 100)) {
				quantityString = JOptionPane.showInputDialog("Invalid quantity, please enter again: ");
			}
		} while(!(quantity >= 1 && quantity < 100));
		// get product ID
		int productID = (int) this.smartShopperView.getProductListTable().getValueAt(selectRow, 0);
		Purchase  purchase = new Purchase(-1, productID, this.smartShopperModel.getLoginUser().getPid(), quantity);
		// insert purchase
		try {
			purchaseMysql.insert(purchase);
			JOptionPane.showMessageDialog(smartShopperView, "Success add to purchase list!");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(smartShopperView, "Fail add purchase list!");
		}
	}
	
	// display stroe list window
	private void storeListButtonActionPerformed() {
		try {
			if(!login()) {
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		storeController.displayWindow();
	}
	
	// display purchase list window
	private void purchaseListButtonActionPerformed() {
		try {
			if (!login()) {
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(!this.smartShopperModel.isCustomer()) {
			JOptionPane.showMessageDialog(smartShopperView, "Only customer can open purchase list!");
			return;
		}
		purchaseListController.displayWindow();
	}
		
	// display people list window
	private void peopleListButtonActionPerformed() {
		try {
			if (!login()) {
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (!this.smartShopperModel.isAdministrator()) {
			JOptionPane.showMessageDialog(smartShopperView, "Only administrator can modify people!");
			return;
		}
		peopleController.displayWindow();
	}
		
	// modify item
	private void modifyButtonActionPerformed() throws Exception {
		// display log in window if not have log in
		if (!login()) {
			return;
		}
		int selectRow = this.smartShopperView.getProductListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(smartShopperView, "Please select one product!");
			return;
		}
		int productID = (int) this.smartShopperView.getProductListTable().getValueAt(selectRow, 0);
		Product product = productMysql.getProduct(productID);
		this.smartShopperModel.setModifiedProduct(product);
		displayAddOrModifyItemView(product);
	}

	// user log in
	public boolean login() throws Exception {
		if (this.loginController.isLogined()) {
			return true;
		} else if (!loginController.checkLogin()) { // fail login
			return false;
		}
		// initialize data after first log in
		smartShopperView.getUsernameLabel().setText(smartShopperModel.getLoginUser().getFullName());
		smartShopperView.getRoleLabel().setText(smartShopperModel.getLoginUser().getRole());
		this.smartShopperView.getAddItemButton().setVisible(isCanModifyItem());
		this.smartShopperView.getModifyButton().setVisible(isCanModifyItem());
		this.smartShopperView.getDeleteItemButton().setVisible(isCanModifyItem());
		this.smartShopperView.getPurchaseListButton().setVisible(this.smartShopperModel.isCustomer());
		this.smartShopperView.getAddPurchaseButton().setVisible(this.smartShopperModel.isCustomer());
		this.smartShopperView.getRecommandButton().setVisible(this.smartShopperModel.isCustomer());
		this.smartShopperView.getPeopleListButton().setVisible(this.smartShopperModel.isAdministrator());
		// manager can only change his store's item
		if (smartShopperModel.isManager()) {
			this.addModifyItemView.getStoreComboBox().setSelectedItem(smartShopperModel.getLoginManager().getStore());
			this.addModifyItemView.getStoreComboBox().setEnabled(false);
		} else if (smartShopperModel.isAdministrator()) {
			// administrator can change every store's item
			this.addModifyItemView.getStoreComboBox().setEditable(true);
			this.addModifyItemView.getStoreComboBox().setEnabled(true);
		}

		// manager can only change his store's item
		if (smartShopperModel.isManager()) {
			smartShopperView.setProductData(productMysql.getItemList(smartShopperModel.getLoginManager().getSid(), -1));
			// disable Store combobox for manager
			smartShopperView.getStoreComboBox().setSelectedItem(smartShopperModel.getLoginManager().getStore());
			smartShopperView.getStoreComboBox().setEnabled(false);
		}

		return true;
	}

	// delete item
	private void deleteItem() {
		try {
			if (!login()) {
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (!isCanModifyItem()) {
			JOptionPane.showMessageDialog(smartShopperView, "Only manager or administrator can delete item!");
			return;
		}
		int selectRow = this.smartShopperView.getProductListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(smartShopperView, "Please select one item!");
			return;
		}
		// confirm with user to delete item
		if (JOptionPane.showConfirmDialog(smartShopperView, "Confirm to delete this item?") != JOptionPane.OK_OPTION) {
			return;
		}
		int productID = (int) this.smartShopperView.getProductListTable().getValueAt(selectRow, 0);
		try {
			productMysql.deleteProduct(productID);
			JOptionPane.showMessageDialog(smartShopperView, "Success delete item!");
			refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(smartShopperView, "Fail delete item!");
		}
	}

	// only manager or administrator can add item
	private boolean isCanModifyItem() {
		return smartShopperModel.isAdministrator() || smartShopperModel.isManager();
	}

	// display add item's dialog
	private void displayAddOrModifyItemView(Product product) {
		if (!this.isCanModifyItem()) {
			if (product == null) {
				JOptionPane.showMessageDialog(this.smartShopperView, "Only manager or administrator can add item!");
			} else {
				JOptionPane.showMessageDialog(this.smartShopperView, "Only manager or administrator can modify item!");
			}
			return;
		}
		// add item
		if (product == null) {
			this.addModifyItemView.setTitle("Add Item");
		} else {
			this.addModifyItemView.setTitle("Modify Item");
		}
		this.addModifyItemView.clear();
		// modify item
		if (product != null) {
			this.addModifyItemView.getItemNameTextField().setText(product.getName());
			this.addModifyItemView.getPriceTextField().setText("" + product.getPrice());
			this.addModifyItemView.getAisleTextField().setText(product.getAisle());
			this.addModifyItemView.getStockTextField().setText("" + product.getStock());
			Store store = this.smartShopperModel.getStore(product.getSid());
			this.addModifyItemView.getStoreComboBox().setSelectedItem(store);
			this.addModifyItemView.getOnSaleComboBox().setSelectedItem(product.isOnSale() ? "true" : "false");
			Category category = this.smartShopperModel.getCategory(product.getCategoryId());
			this.addModifyItemView.getCategoryComboBox().setSelectedItem(category);
		}
		this.addModifyItemView.setVisible(true);
	}

	// set action listener in add item
	private void initAddItemView() {
		// display category list
		this.addModifyItemView.setCategoryList(smartShopperModel.getCategoryList());
		// display store list
		this.addModifyItemView.setStoreList(smartShopperModel.getStoreList());
		this.addModifyItemView.getAddItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addItemModifyItemActionPerformed();
			}
		});
	}

	private void addItemModifyItemActionPerformed() {
		if (this.addModifyItemView.getTitle().startsWith("Add")) {
			doAddOrModifyItem(null);
		} else {
			doAddOrModifyItem(this.smartShopperModel.getModifiedProduct());
		}
	}

	// add or modify product
	private void doAddOrModifyItem(Product product) {
		String itemName = this.addModifyItemView.getItemNameTextField().getText();
		double price = 0;
		String priceString = this.addModifyItemView.getPriceTextField().getText();
		String aisle = this.addModifyItemView.getAisleTextField().getText();
		String stockString = this.addModifyItemView.getStockTextField().getText();
		int stock = 0;
		int storeID = ((Store) this.addModifyItemView.getStoreComboBox().getSelectedItem()).getSid();
		String onSaleString = this.addModifyItemView.getOnSaleComboBox().getSelectedItem().toString();
		boolean onSale = onSaleString.equals("true") ? true : false;
		int categoryID = ((Category) this.addModifyItemView.getCategoryComboBox().getSelectedItem()).getCid();
		if (itemName.isEmpty()) {
			JOptionPane.showMessageDialog(smartShopperView, "Please enter item name!");
			return;
		} else if (priceString.isEmpty()) {
			JOptionPane.showMessageDialog(smartShopperView, "Please enter price!");
			return;
		} else if (aisle.isEmpty()) {
			JOptionPane.showMessageDialog(smartShopperView, "Please enter aisle!");
			return;
		} else if (stockString.isEmpty()) {
			JOptionPane.showMessageDialog(smartShopperView, "Please enter stock!");
			return;
		}
		try {
			price = Double.parseDouble(priceString);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(smartShopperView, "Invalid price!");
			return;
		}
		try {
			stock = Integer.parseInt(stockString);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(smartShopperView, "Invalid stock!");
			return;
		}
		try {
			// insert product
			if (product == null) {
				product = new Product(-1, itemName, price, storeID, aisle, onSale, stock, categoryID);
				productMysql.insertProduct(product);
				JOptionPane.showMessageDialog(this.addModifyItemView, "Success add item!");
			} else {
				// modify product
				Product newProduct = new Product(-1, itemName, price, storeID, aisle, onSale, stock, categoryID);
				newProduct.setPrid(product.getPrid());
				productMysql.modifyProduct(newProduct);
				JOptionPane.showMessageDialog(this.addModifyItemView, "Success modify item!");
			}
			this.addModifyItemView.setVisible(false);
			this.addModifyItemView.clear();
			this.refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// get item list by store, category
	private void refreshItemList() {
		try {
			this.smartShopperView.setProductData(
					productMysql.getItemList(smartShopperModel.getStoreID(), smartShopperModel.getCategoryID()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void search() {
		String name = this.smartShopperView.getProductNametextField().getText();
		try {
			this.smartShopperView.setProductData(
					productMysql.searchItem(smartShopperModel.getStoreID(), smartShopperModel.getCategoryID(), name));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// display the main window
	public void displaySystem() {
		smartShopperView.setVisible(true);
	}
}

