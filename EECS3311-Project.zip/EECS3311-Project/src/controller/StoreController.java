package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.SmartShopperModel;
import model.Store;
import model.StoreMysql;
import view.AddModifyStoreView;
import view.StoreView;

// add, modify, delete Store
public class StoreController {
	private SmartShopperModel smartShopperModel;
	private StoreView storeView;
	private StoreMysql storeMysql;
	private AddModifyStoreView addModifyStoreView;
	private LoginController loginController;
	private JFrame parent;
	
	public StoreController(SmartShopperModel smartShopperModel, JFrame parent) {
		this.smartShopperModel = smartShopperModel;
		this.storeView = new StoreView(parent);
		this.parent = parent;
		storeMysql = new StoreMysql();
		addModifyStoreView = new AddModifyStoreView(this.parent);
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		loginController = new LoginController(smartShopperModel, parent);
	}

	private void initialize() throws Exception {
		// add modify button's listener
		this.storeView.addModifyLisener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					modifyButtonActionPerformed();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		// add item's listener
		this.storeView.getAddItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// display log in window if not have log in
				try {
					if (checkLogin()) {
						displayAddOrModifyItemView(null);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		this.storeView.getDeleteItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteStore();
			}
		});
		initAddItemView();
	}

	// modify item
	private void modifyButtonActionPerformed() throws Exception {
		// display log in window if not have log in
		if (!checkLogin()) {
			return;
		}
		int selectRow = this.storeView.getItemListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(storeView, "Please select one store!");
			return;
		}
		int id = (int) this.storeView.getItemListTable().getValueAt(selectRow, 0);
		Store store = storeMysql.getStore(id);
		this.smartShopperModel.setModifiedStore(store);
		displayAddOrModifyItemView(store);
	}

	// user log in
	private boolean checkLogin() throws Exception {
		if (this.loginController.isLogined()) {
			return true;
		} else if (!loginController.checkLogin()) { // fail login
			return false;
		}
		// initialize data after first log in
		storeView.getUsernameLabel().setText(smartShopperModel.getLoginUser().getFullName());
		storeView.getRoleLabel().setText(smartShopperModel.getLoginUser().getRole());
		this.storeView.getAddItemButton().setVisible(isCanModifyItem());
		this.storeView.getModifyButton().setVisible(isCanModifyItem());
		this.storeView.getDeleteItemButton().setVisible(isCanModifyItem());

		return true;
	}

	// delete item
	public void deleteStore() {
		try {
			if (!checkLogin()) {
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (!isCanModifyItem()) {
			JOptionPane.showMessageDialog(storeView, "Only manager or administrator can delete store!");
			return;
		}
		int selectRow = this.storeView.getItemListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(storeView, "Please select one store!");
			return;
		}
		// confirm with user to delete item
		if (JOptionPane.showConfirmDialog(storeView, "Confirm to delete this store?") != JOptionPane.OK_OPTION) {
			return;
		}
		int id = (int) this.storeView.getItemListTable().getValueAt(selectRow, 0);
		try {
			storeMysql.deleteStore(id);
			JOptionPane.showMessageDialog(storeView, "Success delete store!");
			refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(storeView, "Fail delete store!");
		}
	}

	// only manager or administrator can add item
	private boolean isCanModifyItem() {
		return smartShopperModel.isAdministrator() || smartShopperModel.isManager();
	}

	// display add item's dialog
	private void displayAddOrModifyItemView(Store store) {
		// add item
		if (store == null) {
			this.addModifyStoreView.setTitle("Add Store");
		} else {
			this.addModifyStoreView.setTitle("Modify Store");
		}
		this.addModifyStoreView.clear();
		// modify item
		if (store != null) {
			this.addModifyStoreView.getStoreNameTextField().setText(store.getName());
			this.addModifyStoreView.getLocationTextField().setText(store.getLocation());
			this.addModifyStoreView.getOpenHourTextField().setText("" + store.getOpenHour());
			this.addModifyStoreView.getCloseHourTextField().setText("" + store.getCloseHour());
			this.smartShopperModel.setModifiedStore(store);
		}
		// display window
		this.addModifyStoreView.setVisible(true);
	}

	// set action listener in add item
	private void initAddItemView() {
		this.addModifyStoreView.getOkButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addItemModifyItemActionPerformed();
			}
		});
	}

	private void addItemModifyItemActionPerformed() {
		if (this.addModifyStoreView.getTitle().startsWith("Add")) {
			addStore();
		} else {
			updateStore();
		}
	}

	public void addStore() {
		doAddOrModifyItem(null);
	}
	
	public void updateStore() {
		doAddOrModifyItem(this.smartShopperModel.getModifiedStore());
	}
	
	// add or modify store
	private void doAddOrModifyItem(Store store) {
		int openHour;
		int closeHour;
		String storeName = this.addModifyStoreView.getStoreNameTextField().getText();
		String location = this.addModifyStoreView.getLocationTextField().getText();
		String openHourString = this.addModifyStoreView.getOpenHourTextField().getText();
		String closeHourString = this.addModifyStoreView.getCloseHourTextField().getText();
		if (storeName.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Please enter store name!");
			return;
		} else if (location.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Please enter location!");
			return;
		} else if (openHourString.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Please enter open hour!");
			return;
		} else if (closeHourString.isEmpty()) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Please enter close hour!");
			return;
		}
		try {
			openHour = Integer.parseInt(openHourString);
			if(!(openHour >= 0 && openHour <= 24)) {
				JOptionPane.showMessageDialog(addModifyStoreView, "Invalid open hour!");
				return;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Invalid open hour!");
			return;
		}
		try {
			closeHour = Integer.parseInt(closeHourString);
			if(!(closeHour >= 0 && closeHour <= 24)) {
				JOptionPane.showMessageDialog(addModifyStoreView, "Invalid close hour!");
				return;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(addModifyStoreView, "Invalid close hour!");
			return;
		}
		try {
			// insert store
			if (store == null) {
				store = new Store(-1, storeName, location, openHour, closeHour);
				storeMysql.insertStore(store);
				JOptionPane.showMessageDialog(this.addModifyStoreView, "Success add store!");
			} else {
				// modify store
				Store newStore = new Store(-1, storeName, location, openHour, closeHour);
				newStore.setSid(store.getSid());
				storeMysql.modifyStore(newStore);
				JOptionPane.showMessageDialog(this.addModifyStoreView, "Success modify store!");
			}
			this.addModifyStoreView.setVisible(false);
			this.addModifyStoreView.clear();
			this.refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// get item list
	private void refreshItemList() {
		try {
			// manager can only change his store
			if (smartShopperModel.isManager()) {
				storeView.setItemsData(storeMysql.getItemList(smartShopperModel.getLoginManager().getSid()));
			} else {
				storeView.setItemsData(storeMysql.getItemList(-1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// display the window
	public void displayWindow() {
		refreshItemList();
		storeView.getDeleteItemButton().setVisible(false);
		storeView.getAddItemButton().setVisible(this.smartShopperModel.isAdministrator());
		storeView.getModifyButton().setVisible(this.smartShopperModel.isAdministrator() || this.smartShopperModel.isManager());
		storeView.getDeleteItemButton().setVisible(this.smartShopperModel.isAdministrator() || this.smartShopperModel.isManager());
		storeView.getUsernameLabel().setText(this.smartShopperModel.getLoginUser().getFullName());
		storeView.getRoleLabel().setText(this.smartShopperModel.getLoginUser().getRole());
		storeView.setVisible(true);
	}
}
