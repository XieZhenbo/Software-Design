package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import model.PurchaseMysql;
import model.SmartShopperModel;
import view.PurchaseListView;

// add, modify, delete customer's purchase list
public class PurchaseListController {
	private SmartShopperModel smartShopperModel;
	private PurchaseListView purchaseListView;
	private PurchaseMysql purchaseMysql;
	private JFrame parent;
	
	public PurchaseListController(SmartShopperModel smartShopperModel, JFrame parent) {
		this.smartShopperModel = smartShopperModel;
		this.purchaseListView = new PurchaseListView(parent);
		this.parent = parent;
		purchaseMysql = new PurchaseMysql();
		try {
			initialize();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initialize() throws Exception {
		this.purchaseListView.getDeleteItemButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteActionPerformed();
			}
		});
	}

	// delete item
	private void deleteActionPerformed() {
		int selectRow = this.purchaseListView.getItemListTable().getSelectedRow();
		if (selectRow < 0) {
			JOptionPane.showMessageDialog(purchaseListView, "Please select one store!");
			return;
		}
		// confirm with user to delete item
		if (JOptionPane.showConfirmDialog(purchaseListView, "Confirm to delete this store?") != JOptionPane.OK_OPTION) {
			return;
		}
		int id = (int) this.purchaseListView.getItemListTable().getValueAt(selectRow, 0);
		try {
			purchaseMysql.delete(id);
			JOptionPane.showMessageDialog(purchaseListView, "Success delete store!");
			refreshItemList();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(purchaseListView, "Fail delete store!");
		}
	}

	// get item list
	private void refreshItemList() {
		try {
			purchaseListView.setItemsData(purchaseMysql.getItemList(this.smartShopperModel.getLoginUser().getPid()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// display the window
	public void displayWindow() {
		refreshItemList();
		purchaseListView.getDeleteItemButton().setVisible(true);
		purchaseListView.getAddItemButton().setVisible(false);
		purchaseListView.getModifyButton().setVisible(false);
		purchaseListView.getUsernameLabel().setText(this.smartShopperModel.getLoginUser().getFullName());
		purchaseListView.getRoleLabel().setText(this.smartShopperModel.getLoginUser().getRole());
		purchaseListView.setVisible(true);
	}
}
