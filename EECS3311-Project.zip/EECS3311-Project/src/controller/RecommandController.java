package controller;

import javax.swing.JFrame;

import model.ProductMysql;
import model.SmartShopperModel;
import view.RecommandView;

// display recommand product list
public class RecommandController {
	private SmartShopperModel smartShopperModel;
	private RecommandView recommandView;
	private ProductMysql productMysql;
	private JFrame parent;
	
	public RecommandController(SmartShopperModel smartShopperModel, JFrame parent) {
		this.smartShopperModel = smartShopperModel;
		this.recommandView = new RecommandView(parent);
		this.parent = parent;
		productMysql = new ProductMysql();
	}

	// get item list
	private void refreshItemList() {
		try {
			recommandView.setItemsData(productMysql.getRecommand());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// display the window
	public void displayWindow() {
		refreshItemList();
		recommandView.setVisible(true);
	}
}

