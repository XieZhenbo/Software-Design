package app;
import controller.SmartShopperController;
import model.SmartShopperModel;
import view.SmartShopperView;

// main program
public class SmartShopperApp {
	public static void main(String[] args) {
		SmartShopperController controller = new SmartShopperController(new SmartShopperModel(), new SmartShopperView());
		controller.displaySystem();
	}
}

