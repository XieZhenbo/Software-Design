package model;

public class Store {
	private int sid;
	private String name;
	private String location;
	private int openHour;
	private int closeHour;

	public Store(int sid, String name, String location, int openHour, int closeHour) {
		this.sid = sid;
		this.name = name;
		this.location = location;
		this.openHour = openHour;
		this.closeHour = closeHour;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getOpenHour() {
		return openHour;
	}

	public void setOpenHour(int openHour) {
		this.openHour = openHour;
	}

	public int getCloseHour() {
		return closeHour;
	}

	public void setCloseHour(int closeHour) {
		this.closeHour = closeHour;
	}
	
	public String toString() {
		return this.name;
	}

	public boolean equals(Object arg) {
		if(arg instanceof Store) {
			return ((Store)arg).getSid() == this.sid;
		}
		return false;
	}
}
