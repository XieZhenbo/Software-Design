package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class CategoryMysql extends Mysql{
	// get all category
	public List<Category> getAllCategory() throws Exception{
		List<Category> result = new ArrayList<Category>();
		String sql = "SELECT cid, name "
				+ "FROM category ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		for(Vector<Object> v : data) {
			result.add(new Category((int)v.get(0), (String)v.get(1)));
		}
		return result;
	}
}
