package model;

public class Customer extends People {
	public Customer(int pid, String name, String username, String password, String role) {
		super(pid, name, username, password, role);
	}

	private String location;
	private int preferenceStore;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getPreferenceStore() {
		return preferenceStore;
	}

	public void setPreferenceStore(int preferenceStore) {
		this.preferenceStore = preferenceStore;
	}
}
