package model;

public class Manager extends People {
	private int sid;
	private Store store;

	public Manager(int pid, String fullName, String username, String password, String role) {
		super(pid, fullName, username, password, role);
	}

	public Manager(int pid, String fullName, String username, String password, String role, int storeID) {
		super(pid, fullName, username, password, role);
		this.sid = storeID;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}
}

