package model;

public class Administrator extends People {
	private String status;

	public Administrator(int pid, String fullName, String username, String password, String role) {
		super(pid, fullName, username, password, role);
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
