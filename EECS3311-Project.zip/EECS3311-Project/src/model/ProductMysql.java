package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Vector;

public class ProductMysql extends Mysql{
	// get all item list by category in the given store
	public Vector<Vector<Object>> getItemList(int storeID, int categoryID) throws Exception{
		String sql = "SELECT prid, p.name, p.price, s.name, p.aisle, p.on_sale, p.stock, c.name "
				+ "FROM product p "
				+ "JOIN store s ON p.sid = s.sid "
				+ "JOIN category c ON c.cid = p.category_id "
				+ " WHERE 1 = 1 ";
		if(storeID >= 0) {
			sql += " and s.sid = ? ";
		}
		if(categoryID >= 0) {
			sql += " and p.category_id = ? ";
		}
		sql += " order by s.name, p.aisle, p.name";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		if(storeID >= 0) {
			statement.setInt(1, storeID);
		}
		if(categoryID >= 0) {
			int i = 1;
			if(storeID >= 0) {
				i = 2;
			}
			statement.setInt(i, categoryID);
		}
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		return data;
	}
	
	// get recommand
	public Vector<Vector<Object>> getRecommand() throws Exception{
		String sql = "SELECT store.name AS store_name, aisle, product.name AS product_name, price, category.name AS category_name, on_sale\r\n" + 
				"FROM product \r\n" + 
				"JOIN category ON product.category_id = category.cid\r\n" + 
				"JOIN store ON store.sid = product.sid\r\n" +
				"WHERE on_sale = 1 "; 
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		return data;
	}
	
	public Vector<Vector<Object>> searchItem(int storeID, int categoryID, String name) throws Exception{
		String sql = "SELECT prid, p.name, p.price, s.name, p.aisle, p.on_sale, p.stock, c.name "
				+ "FROM product p "
				+ "JOIN store s ON p.sid = s.sid "
				+ "JOIN category c ON c.cid = p.category_id "
				+ " WHERE p.name like ?";
		if(storeID >= 0) {
			sql += " and s.sid = ? ";
		}
		if(categoryID >= 0) {
			sql += " and p.category_id = ? ";
		}
		sql += " order by s.name, p.aisle, p.name";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, "%" + name + "%");
		if(storeID >= 0) {
			statement.setInt(2, storeID);
		}
		if(categoryID >= 0) {
			int i = 2;
			if(storeID >= 0) {
				i = 3;
			}
			statement.setInt(i, categoryID);
		}		
		return getQueryResult(statement);
	}
	
	public boolean insertProduct(Product product)  throws Exception{
		String sql = "INSERT INTO product(prid, name, price, sid, aisle, on_sale, stock, category_id) " + 
				"SELECT MAX(prid) + 1, ?, ?, ?, ?, ?, ?, ? " + 
				"FROM product;";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, product.getName());
		statement.setDouble(2, product.getPrice());
		statement.setInt(3, product.getSid());
		statement.setString(4, product.getAisle());
		statement.setInt(5, product.isOnSale() ? 1 : 0);
		statement.setInt(6, product.getStock());
		statement.setInt(7, product.getCategoryId());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	public boolean modifyProduct(Product product) throws Exception{
		String sql = "update product set name = ?, price = ?, sid = ?, aisle = ?, on_sale = ?, stock = ?, category_id = ? " + 
				" WHERE prid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, product.getName());
		statement.setDouble(2, product.getPrice());
		statement.setInt(3, product.getSid());
		statement.setString(4, product.getAisle());
		statement.setInt(5, product.isOnSale() ? 1 : 0);
		statement.setInt(6, product.getStock());
		statement.setInt(7, product.getCategoryId());
		statement.setInt(8, product.getPrid());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}

	public Product getProduct(int productID) throws Exception{
		String sql = "SELECT prid, name, price, sid, aisle, on_sale, stock, category_id "
				+ "FROM product "
				+ "WHERE prid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, productID);
		Vector<Vector<Object>> data = getQueryResult(statement);
		if(data.isEmpty()) {
			return null;
		} else {
			Vector<Object> v = data.get(0);
			return new Product((int)v.get(0), (String)v.get(1), Double.parseDouble(v.get(2).toString()), (int)v.get(3)
					, (String)v.get(4), ((int)v.get(5)) == 1 ? true : false, (int)v.get(6), (int)v.get(7));
		}
	}
	
	public boolean deleteProduct(int productID) throws Exception{
		String sql = "DELETE FROM product "
				+ "WHERE prid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, productID);
		statement.execute();
		return true;
	}
}
