package model;

public class Product {
	private int prid;
	private String name;
	private double price;
	private int sid;
	private String aisle;
	private boolean onSale;
	private int stock;
	private int categoryId;
	private String storeName;
	private String categoryName;

	public Product(int prid, String name, double price, int sid, String aisle, boolean onSale, int stock,
			int categoryId) {
		this.prid = prid;
		this.name = name;
		this.price = price;
		this.sid = sid;
		this.aisle = aisle;
		this.onSale = onSale;
		this.stock = stock;
		this.categoryId = categoryId;
	}

	public int getPrid() {
		return prid;
	}

	public void setPrid(int prid) {
		this.prid = prid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getAisle() {
		return aisle;
	}

	public void setAisle(String aisle) {
		this.aisle = aisle;
	}

	public boolean isOnSale() {
		return onSale;
	}

	public void setOnSale(boolean onSale) {
		this.onSale = onSale;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
}
