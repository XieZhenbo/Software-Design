package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class Mysql {
	// return mysql's connection
	public Connection getConnection() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String URL = "jdbc:mysql://127.0.0.1:3306/store";
		Connection connection = DriverManager.getConnection(URL, "root", "root1234");
		return connection;
	}
	
	// return query result
	public Vector<Vector<Object>> getQueryResult(PreparedStatement preparedStatement) throws Exception{
		Vector<Vector<Object>> result = new Vector<Vector<Object>>();
		Vector<Object> row;
		ResultSet rs = preparedStatement.executeQuery();
		// get every records
        while (rs.next()) {
        	row = new Vector<Object>();
            for(int i = 1;i <= rs.getMetaData().getColumnCount();i++){
            	row.add(rs.getObject(i));
            }
            result.add(row);
        }
        preparedStatement.close();
        return result;
	}
}
