package model;

import java.util.List;

public class SmartShopperModel {
	private int storeID = -1;
	private int categoryID = -1;
	private People loginUser;
	private Manager loginManager;
	private List<Store> storeList;
	private List<Category> categoryList;
	private Product modifiedProduct;
	private Store modifiedStore;
	private People modifiedPeople;

	public int getStoreID() {
		return storeID;
	}

	public void setStoreID(int storeID) {
		this.storeID = storeID;
	}

	public int getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(int categoryID) {
		this.categoryID = categoryID;
	}

	public People getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(People loginUser) {
		this.loginUser = loginUser;
	}

	public boolean isLoginUser() {
		return loginUser != null;
	}

	public List<Store> getStoreList() {
		return storeList;
	}

	public void setStoreList(List<Store> storeList) {
		this.storeList = storeList;
	}

	public Manager getLoginManager() {
		return loginManager;
	}

	public void setLoginManager(Manager loginManager) {
		this.loginManager = loginManager;
	}

	public Store getStoreById(int storeID) {
		for (Store s : storeList) {
			if (s.getSid() == storeID) {
				return s;
			}
		}
		return null;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public Product getModifiedProduct() {
		return modifiedProduct;
	}

	public void setModifiedProduct(Product modifiedProduct) {
		this.modifiedProduct = modifiedProduct;
	}

	public Store getStore(int storeID) {
		for (Store s : storeList) {
			if (s.getSid() == storeID) {
				return s;
			}
		}
		return null;
	}

	public Category getCategory(int categoryID) {
		for (Category c : categoryList) {
			if (c.getCid() == categoryID) {
				return c;
			}
		}
		return null;
	}

	public boolean isManager() {
		return getLoginUser() != null && getLoginUser().getRole().equals("manager");
	}

	public boolean isAdministrator() {
		return getLoginUser() != null && getLoginUser().getRole().equals("admin");
	}

	public boolean isCustomer() {
		return getLoginUser() != null && getLoginUser().getRole().equals("customer");
	}

	public Store getModifiedStore() {
		return modifiedStore;
	}

	public void setModifiedStore(Store modifiedStore) {
		this.modifiedStore = modifiedStore;
	}

	public People getModifiedPeople() {
		return modifiedPeople;
	}

	public void setModifiedPeople(People modifiedPeople) {
		this.modifiedPeople = modifiedPeople;
	}
}
