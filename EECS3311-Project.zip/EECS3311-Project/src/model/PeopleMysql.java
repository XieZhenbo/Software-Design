package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class PeopleMysql extends Mysql{
	// get list of people
	public Vector<Vector<Object>> getItemList() throws Exception{
		String sql = "SELECT pid, name, username, password, role "
				+ "FROM people ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		return data;
	}

	// get People by pid
	public People getPeople(int pid) throws Exception{
		List<Store> result = new ArrayList<Store>();
		String sql = "SELECT pid, name, username, password, role "
				+ "FROM people "
				+ "WHERE pid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, pid);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		if(data.isEmpty()) {
			return null;
		} else {
			Vector v = data.get(0);
			return new People((int)v.get(0), (String)v.get(1), (String)v.get(2), (String)v.get(3), (String)v.get(4));	
		}
	}
	
	// get People by username and password, return null if can't find
	public People getPeople(String username, String password) throws Exception{
		List<Store> result = new ArrayList<Store>();
		String sql = "SELECT pid, name, username, password, role "
				+ "FROM people "
				+ "WHERE username = ? and password = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, username);
		statement.setString(2, password);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		if(data.isEmpty()) {
			return null;
		} else {
			Vector v = data.get(0);
			return new People((int)v.get(0), (String)v.get(1), (String)v.get(2), (String)v.get(3), (String)v.get(4));	
		}
	}
	
	public boolean insertPeople(People people)  throws Exception{
		String sql = "INSERT INTO people(pid, name, username, password, role) " + 
				"SELECT MAX(pid) + 1, ?, ?, ?, ? " + 
				"FROM people;";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, people.getFullName());
		statement.setString(2, people.getUsername());
		statement.setString(3, people.getPassword());
		statement.setString(4, people.getRole());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	public boolean deletePeople(int pid)  throws Exception{
		String sql = "DELETE FROM people " + 
				"WHERE pid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, pid);
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	// update people
	public boolean modify(People people) throws Exception {
		String sql = "UPDATE people set name = ?, username = ?, password = ?, role = ? "
				+ "WHERE pid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, people.getFullName());
		statement.setString(2, people.getUsername());
		statement.setString(3, people.getPassword());
		statement.setString(4, people.getRole());
		statement.setInt(5, people.getPid());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
}
