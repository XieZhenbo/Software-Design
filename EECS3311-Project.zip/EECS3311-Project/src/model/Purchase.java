package model;

public class Purchase {
	private int purchaseID;
	private int productID;
	private int customerID;
	private int quantity;

	public Purchase(int purchaseID, int productID, int customerID, int quantity) {
		this.purchaseID = purchaseID;
		this.productID = productID;
		this.customerID = customerID;
		this.quantity = quantity;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPurchaseID() {
		return purchaseID;
	}

	public void setPurchaseID(int purchaseID) {
		this.purchaseID = purchaseID;
	}
}
