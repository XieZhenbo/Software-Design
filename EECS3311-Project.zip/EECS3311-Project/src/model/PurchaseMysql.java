package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class PurchaseMysql extends Mysql{
	// get purchase list
	public Vector<Vector<Object>> getItemList(int customerID) throws Exception{
		String sql = "SELECT purchase_id, product.name AS product_name, product.price, purchase.quantity, store.name AS store_name, product.aisle\r\n" + 
				"FROM purchase\r\n" + 
				"JOIN product ON purchase.prid = product.prid\r\n" + 
				"JOIN store ON store.sid = product.sid\r\n"+
				"WHERE purchase.cid = ?";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, customerID);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		return data;
	}

	public boolean insert(Purchase purchase)  throws Exception{
		String sql = "INSERT INTO purchase(purchase_id, prid, cid, quantity) " + 
				"SELECT ifnull(MAX(purchase_id), 0) + 1, ?, ?, ? " + 
				"FROM purchase;";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, purchase.getProductID());
		statement.setInt(2, purchase.getCustomerID());
		statement.setInt(3, purchase.getQuantity());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	public boolean delete(int purchaseID)  throws Exception{
		String sql = "DELETE FROM purchase " + 
				"WHERE purchase_id = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, purchaseID);
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
}
