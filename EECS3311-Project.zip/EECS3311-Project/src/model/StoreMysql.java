package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class StoreMysql extends Mysql{
	// get all item list
	public Vector<Vector<Object>> getItemList(int storeID) throws Exception{
		String sql = "SELECT sid, name, location, open_hour, close_hour "
				+ "FROM store "
				+ " WHERE 1 = 1 ";
		if(storeID >= 0) {
			sql += " and sid = ? ";
		}
		sql += " order by sid";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		if(storeID >= 0) {
			statement.setInt(1, storeID);
		}
		return getQueryResult(statement);
	}
	
	// get all category
	public List<Store> getAllStore() throws Exception{
		List<Store> result = new ArrayList<Store>();
		String sql = "SELECT sid, name, location, open_hour, close_hour "
				+ "FROM store ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		Vector<Vector<Object>> data = getQueryResult(statement);
		for(Vector<Object> v : data) {
			result.add(new Store((int)v.get(0), (String)v.get(1), (String)v.get(2), (int)v.get(3), (int)v.get(4)));
		}
		return result;
	}
	
	// insert store
	public boolean insertStore(Store store) throws Exception {
		String sql = "INSERT INTO store(sid, name, location, open_hour, close_hour) "
				+ "SELECT MAX(sid) + 1, ?, ?, ?, ? "
				+ "FROM store ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, store.getName());
		statement.setString(2, store.getLocation());
		statement.setInt(3, store.getOpenHour());
		statement.setInt(4, store.getCloseHour());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}

	// update store
	public boolean modifyStore(Store store) throws Exception {
		String sql = "UPDATE store set name = ?, location = ?, open_hour = ?, close_hour = ? "
				+ "WHERE sid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, store.getName());
		statement.setString(2, store.getLocation());
		statement.setInt(3, store.getOpenHour());
		statement.setInt(4, store.getCloseHour());
		statement.setInt(5, store.getSid());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	// delete store
	public boolean deleteStore(int storeID) throws Exception{
		String sql = "DELETE FROM store "
				+ "WHERE sid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, storeID);
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	// get store
	public Store getStore(int storeID) throws Exception {
		String sql = "SELECT sid, name, location, open_hour, close_hour "
				+ "FROM store "
				+ "WHERE sid = ? ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, storeID);
		Vector<Vector<Object>> data = getQueryResult(statement);
		if(data.isEmpty()) {
			return null;
		} else {
			Vector<Object> v = data.get(0);
			return new Store((int)v.get(0), (String)v.get(1), (String)v.get(2), (int)v.get(3), (int)v.get(4));
		}
	}
}
