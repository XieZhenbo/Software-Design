package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Vector;

public class ManagerMysql extends Mysql{
	// insert manager into table
	public boolean insertManager(Manager manager)  throws Exception{
		String sql = "INSERT INTO manager(pid, sid) " + 
				"SELECT MAX(pid), ? "
				+ "FROM people ";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, manager.getSid());
		statement.execute();
		statement.close();
		connection.close();
		return true;
	}
	
	// get manager by id
	public Manager getManager(int peopleId) throws Exception{
		String sql = "SELECT p.pid, p.name, p.username, p.password, p.role, m.sid\r\n" + 
				"FROM people p\r\n" + 
				"JOIN manager m ON p.pid = m.pid\r\n" + 
				"WHERE p.pid = ?";
		Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, peopleId);
		Vector<Vector<Object>> data = getQueryResult(statement);
		connection.close();
		if(data.isEmpty()) {
			return null;
		} else {
			Vector<Object> v = data.get(0);
			return new Manager((int)v.get(0), (String)v.get(1), (String)v.get(2)
					, (String)v.get(3), (String)v.get(4), (int)v.get(5));
		}
	}
}
